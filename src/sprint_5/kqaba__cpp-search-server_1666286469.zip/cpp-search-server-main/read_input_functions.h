#pragma once
#include <string> 
#include <vector> 
std::string ReadLine();
int ReadLineWithNumber();
std::vector<int> ReadLineOfNumbers();