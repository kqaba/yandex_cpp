
#include "request_queue.h"
#include <numeric>
int RequestQueue::GetNoResultRequests() const {
        return no_results_requests_;
    }

